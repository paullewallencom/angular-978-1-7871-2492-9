export interface Task {
  name: string;
  deadline: string;
  pomodorosRequired: number;
  queued: boolean;
}
