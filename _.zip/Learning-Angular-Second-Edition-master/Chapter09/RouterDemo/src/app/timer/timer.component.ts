import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  timer
  `
})
export class TimerComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
