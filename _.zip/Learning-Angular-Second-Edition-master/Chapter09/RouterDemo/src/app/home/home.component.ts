import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  home
  `
})
export class HomeComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
