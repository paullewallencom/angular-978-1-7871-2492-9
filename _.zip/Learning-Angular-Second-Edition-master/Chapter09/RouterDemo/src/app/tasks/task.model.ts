export interface Task {
  title: string;
  id: number;
}
