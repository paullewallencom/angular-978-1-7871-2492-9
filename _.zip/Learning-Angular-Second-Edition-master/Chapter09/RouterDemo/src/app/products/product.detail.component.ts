import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  product detail
  `
})
export class ProductDetailComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
