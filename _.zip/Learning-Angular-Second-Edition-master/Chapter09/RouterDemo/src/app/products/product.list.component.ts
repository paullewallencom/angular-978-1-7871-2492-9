import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  product list
  `
})
export class ProductListComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
