export class Service {
  getData() { }
}