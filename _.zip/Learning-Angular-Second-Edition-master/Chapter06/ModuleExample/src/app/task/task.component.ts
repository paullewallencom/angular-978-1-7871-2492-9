import { Component } from '@angular/core';

@Component({
  selector: 'task',
  template: `a task`
})

export class TaskComponent{
  constructor() { }
}
