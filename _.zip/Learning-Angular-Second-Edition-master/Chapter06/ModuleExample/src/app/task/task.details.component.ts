import { Component } from '@angular/core';

@Component({
  selector: 'task-details',
  template: `task details`
})

export class TaskDetailsComponent{
  constructor() { }
}
