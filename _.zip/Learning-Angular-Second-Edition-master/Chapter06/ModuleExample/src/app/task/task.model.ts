export class Task {
  name: string;
  queued: boolean;
  noRequired: number;
  deadline: Date;
}

