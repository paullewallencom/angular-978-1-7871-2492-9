
import { Song } from "./song.model";

export class SongsService {
  fetch(): Song[] {
    return new Array<Song>();
  }
}
