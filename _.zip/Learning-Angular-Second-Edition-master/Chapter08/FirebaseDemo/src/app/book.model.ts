export class Book {
  title: string;
  constructor(json) {
    this.title = json.title;
  }
}
